package com.example.randomquotegenerator

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var quoteText: TextView
    private lateinit var newQuoteButton: Button
    private lateinit var shareButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        quoteText = findViewById(R.id.quoteText)
        newQuoteButton = findViewById(R.id.newQuoteButton)
        shareButton = findViewById(R.id.shareButton)

        newQuoteButton.setOnClickListener {
            getNewQuote()
        }

        shareButton.setOnClickListener {
            shareQuote()
        }
    }

    private fun getNewQuote() {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val response = RetrofitInstance.api.getRandomQuote()
                if (response.isSuccessful) {
                    val quote = response.body()
                    withContext(Dispatchers.Main) {
                        quoteText.text = "\"${quote?.quote}\" - ${quote?.author}"
                    }
                } else {
                    withContext(Dispatchers.Main) {
                        quoteText.text = "Failed to retrieve quote. Code: ${response.code()}"
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                withContext(Dispatchers.Main) {
                    quoteText.text = "An error occurred: ${e.message}. Please try again later."
                }
            }
        }
    }

    private fun shareQuote() {
        val quote = quoteText.text.toString()
        val sendIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, quote)
            type = "text/plain"
        }
        val shareIntent = Intent.createChooser(sendIntent, null)
        startActivity(shareIntent)
    }
}

package com.example.randomquotegenerator

import retrofit2.Response
import retrofit2.http.GET

// Define the API interface
interface QuoteApi {
    // Fetch a random quote
    @GET("quotes/random")
    suspend fun getRandomQuote(): Response<QuoteResponse>
}

// Data class to model the JSON response
data class QuoteResponse(
    val quote: String,  // The actual quote
    val author: String  // The author of the quote
)
